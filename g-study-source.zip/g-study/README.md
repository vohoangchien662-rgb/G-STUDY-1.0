# G-STUDY — Nền tảng học tiếng Anh lớp 10

G-STUDY là ứng dụng web học tiếng Anh lớp 10, gồm đăng ký/đăng nhập, lộ trình 10 Unit, lưu kết quả học tập, thống kê hôm nay so với hôm qua, trang cá nhân, đổi mật khẩu, tùy chỉnh hình nền và gửi liên hệ quản trị viên.

## Chạy trên máy tính

Yêu cầu Python 3.9 trở lên. Dự án chỉ dùng thư viện chuẩn của Python, không cần cài thêm package.

```bash
python server.py
```

Mở địa chỉ `http://localhost:8090`.

## Tài khoản quản trị khởi tạo

- Email: `admin@lingo10.vn`
- Mật khẩu mặc định: `Admin@123`

**Hãy đăng nhập và đổi mật khẩu quản trị ngay sau lần chạy đầu tiên.** Mục đổi mật khẩu nằm trong tab **Cá nhân**.

## Cấu trúc chính

- `index.html`: giao diện responsive cho máy tính và điện thoại.
- `server.py`: máy chủ Python và API đăng nhập, bài học, thống kê, liên hệ và quản trị.
- `Procfile`: lệnh chạy máy chủ trên nền tảng hosting hỗ trợ Procfile.

## Cơ sở dữ liệu và bảo mật

Khi chạy lần đầu, ứng dụng tự tạo `english10.db` và dữ liệu chương trình học. Không đưa file cơ sở dữ liệu chứa tài khoản thật lên GitHub. File này đã được thêm vào `.gitignore`.

Có thể đặt vị trí cơ sở dữ liệu bằng biến môi trường `DATABASE_PATH`, ví dụ:

```bash
DATABASE_PATH=/var/data/english10.db python server.py
```

Khi triển khai lên Render/Railway, hãy gắn Persistent Disk/Volume và đặt `DATABASE_PATH` trỏ vào thư mục được gắn. Nếu dùng ổ đĩa tạm thời, dữ liệu tài khoản và tiến độ có thể mất khi dịch vụ được triển khai lại.

## Triển khai lên Render

1. Đẩy các file trong thư mục này lên một GitHub repository.
2. Trên Render, chọn **New → Web Service** và kết nối repository.
3. Chọn Runtime **Python**.
4. Đặt Start Command là `python server.py`.
5. Cấu hình Persistent Disk/Volume (ví dụ mount tại `/var/data`) và biến `DATABASE_PATH=/var/data/english10.db`.
6. Deploy. Sau khi deploy, mở URL do Render cấp.

## Các lưu ý tính năng

- Thanh điều hướng điện thoại có 4 mục: Trang chủ, Lộ trình, Thống kê và Cá nhân.
- Chạm logo G-STUDY 5 lần liên tiếp để mở cổng quản trị; chỉ tài khoản có quyền `admin` mới vào được.
- Hình nền được lưu trên trình duyệt/thiết bị hiện tại, không đồng bộ giữa các thiết bị.
- Liên hệ gửi từ trang Cá nhân được lưu trong cơ sở dữ liệu và xuất hiện trong tab **Liên hệ** của quản trị viên.
- Đăng nhập Google và gửi email tự động để đặt lại mật khẩu chưa được cấu hình; cần bổ sung OAuth và dịch vụ email trước khi sử dụng các luồng này trên môi trường thật.
